// ================= UTILITY =================
function getSelectedTextAndRange() {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) {
    return { text: "", apply: () => {} };
  }

  const range = selection.getRangeAt(0);
  const text = selection.toString();

  return {
    text,
    apply: (newText) => {
      range.deleteContents();
      range.insertNode(document.createTextNode(newText));
    }
  };
}

function showPopup(html) {
  const box = document.createElement("div");
  box.style.cssText = `
    position:fixed;
    top:20%;
    left:50%;
    transform:translateX(-50%);
    background:#111;
    color:white;
    padding:15px;
    width:560px;
    z-index:999999;
    border-radius:6px;
    font-family:Arial;
    max-height:70vh;
    overflow-y:auto;
  `;
  box.innerHTML = html;
  document.body.appendChild(box);
  return box;
}

// ================= GRAMMAR =================
const SPELL_STYLE = `
<style>
.spell-error {
  text-decoration: underline;
  text-decoration-color: red;
  text-decoration-thickness: 2px;
}
</style>
`;

function isSpellingRule(ruleId = "") {
  const SPELL_RULES = [
    "MORFOLOGIK",
    "SPELLER",
    "HUNSPELL",
    "TYPO",
    "ORTHOGRAPHY"
  ];
  return SPELL_RULES.some(r => ruleId.toUpperCase().includes(r));
}

function highlightSpelling(text, matches) {
  let highlighted = text;

  matches
    .filter(m => isSpellingRule(m.rule))
    .sort((a, b) => b.offset - a.offset)
    .forEach(m => {
      highlighted =
        highlighted.slice(0, m.offset) +
        `<span class="spell-error">${highlighted.slice(m.offset, m.offset + m.length)}</span>` +
        highlighted.slice(m.offset + m.length);
    });

  return highlighted;
}

function applyGrammarCorrections(text, matches) {
  let corrected = text;

  matches
    .filter(m => m.replacement && !isSpellingRule(m.rule))
    .sort((a, b) => b.offset - a.offset)
    .forEach(m => {
      corrected =
        corrected.slice(0, m.offset) +
        m.replacement +
        corrected.slice(m.offset + m.length);
    });

  return corrected;
}

// ================= GRAMMAR BUTTON =================
const grammarBtn = document.createElement("button");
grammarBtn.innerText = "Grammar";
grammarBtn.style.cssText = `
  position:fixed;
  bottom:20px;
  right:20px;
  z-index:999999;
`;

grammarBtn.onclick = () => {
  const sel = getSelectedTextAndRange();
  if (!sel.text) return alert("Select text first");

  chrome.runtime.sendMessage(
    { type: "GRAMMAR_CHECK", text: sel.text },
    res => {
      console.log("GRAMMAR RAW RESPONSE:", res);

      if (!res || !res.data || !Array.isArray(res.data.matches)) {
        return alert("Grammar check failed");
      }

      const matches = res.data.matches;

      const corrected = applyGrammarCorrections(sel.text, matches);
      const highlighted = highlightSpelling(sel.text, matches);

      let reasons = "<ul>";
      matches.forEach(m => {
        reasons += `<li><b>${m.shortMessage || "Issue"}:</b> ${m.message}</li>`;
      });
      reasons += "</ul>";

      const box = showPopup(`
        ${SPELL_STYLE}
        <b>Detected Issues</b><br><br>
        <div style="border:1px solid #444;padding:8px;">${highlighted}</div><br>

        <b>Auto-corrected Grammar</b><br>
        <textarea style="width:100%;height:80px;">${corrected}</textarea><br><br>

        <b>Explanation:</b>
        ${reasons}

        <button id="apply">Apply</button>
        <button id="close">Close</button>
      `);

      document.getElementById("apply").onclick = () => {
        sel.apply(corrected);
        box.remove();
      };
      document.getElementById("close").onclick = () => box.remove();
    }
  );
};


document.body.appendChild(grammarBtn);

// ================= CLARITY =================
const clarityBtn = document.createElement("button");
clarityBtn.innerText = "Clarity";
clarityBtn.style.cssText = `
  position:fixed;
  bottom:60px;
  right:20px;
  z-index:999999;
`;

clarityBtn.onclick = () => {
  const sel = getSelectedTextAndRange();
  if (!sel.text) return alert("Select text first");

  chrome.runtime.sendMessage(
    { type: "CLARITY_ANALYZE", text: sel.text },
    res => {
      console.log("CLARITY ANALYZE:", res);

      if (!res || !res.scores) {
        return alert("Clarity analysis failed");
      }

      const s = res.scores;

      const box = showPopup(`
        <b>Clarity Analysis</b><br><br>
        Readability: ${s.readability}/30<br>
        Sentence Structure: ${s.sentence_structure}/30<br>
        Academic Tone: ${s.academic_tone}/30<br>
        <b>Total:</b> ${s.total}<br><br>

        <button id="enhance">Enhance Clarity</button>
        <button id="close">Close</button>
      `);

      document.getElementById("enhance").onclick = () => {
        chrome.runtime.sendMessage(
          { type: "CLARITY_IMPROVE", text: sel.text },
          r => {
            console.log("CLARITY IMPROVE:", r);

            if (!r || !r.revised_text) {
              return alert("Clarity improvement failed");
            }

            box.innerHTML = `
              <b>Enhanced Text</b><br><br>
              <textarea style="width:100%;height:100px;">${r.revised_text}</textarea><br><br>

              <b>Before vs After</b><br>
              Readability: ${r.original_scores.readability} → ${r.new_scores.readability}<br>
              Structure: ${r.original_scores.sentence_structure} → ${r.new_scores.sentence_structure}<br>
              Tone: ${r.original_scores.academic_tone} → ${r.new_scores.academic_tone}<br>
              <b>Total:</b> ${r.original_scores.total} → ${r.new_scores.total}<br><br>

              <button id="apply">Apply</button>
              <button id="close">Close</button>
            `;

            document.getElementById("apply").onclick = () => {
              sel.apply(r.revised_text);
              box.remove();
            };
            document.getElementById("close").onclick = () => box.remove();
          }
        );
      };

      document.getElementById("close").onclick = () => box.remove();
    }
  );
};

document.body.appendChild(clarityBtn);

// ================= RESEARCH PAPERS =================
function getFullDocumentText() {
  const cm = document.querySelector(".cm-content");
  return cm ? cm.innerText : "";
}

const researchBtn = document.createElement("button");
researchBtn.innerText = "📚 Papers";
researchBtn.style.cssText = `
  position:fixed;
  bottom:100px;
  right:20px;
  z-index:999999;
`;

researchBtn.onclick = () => {
  const fullText = getFullDocumentText();
  if (!fullText) return alert("Unable to read full document");

  const box = showPopup(`<b>Finding Related Research Papers…</b>`);

  fetch("http://127.0.0.1:8003/research/find", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: fullText })
  })
    .then(res => res.json())
    .then(data => {
      let html = `
        <b>Related Research Papers</b><br><br>
        <b>Domain:</b> ${data.analysis.primary_domain}<br>
        <b>Keywords:</b> ${data.analysis.keywords.join(", ")}<br><hr>
      `;

      data.related_papers.forEach((p, i) => {
        html += `
          <b>${i + 1}. ${p.title}</b><br>
          ${p.authors.join(", ")} ${p.year ? "(" + p.year + ")" : ""}<br>
          <a href="${p.url}" target="_blank">Open Paper</a><hr>
        `;
      });

      html += `<button id="close">Close</button>`;
      box.innerHTML = html;
      document.getElementById("close").onclick = () => box.remove();
    })
    .catch(() => {
      box.innerHTML = `<b>Failed to fetch research papers</b><br><button id="close">Close</button>`;
      document.getElementById("close").onclick = () => box.remove();
    });
};

document.body.appendChild(researchBtn);

