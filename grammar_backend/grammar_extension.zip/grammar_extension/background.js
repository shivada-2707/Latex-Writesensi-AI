chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // ---------------- GRAMMAR ----------------
  if (msg.type === "GRAMMAR_CHECK") {
    fetch("http://127.0.0.1:8001/grammar/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: msg.text })
    })
      .then(res => res.json())
      .then(data => {
        sendResponse({ data });
      })
      .catch(err => {
        console.error("Grammar error:", err);
        sendResponse({ error: true });
      });

    return true; // async response
  }

  // ---------------- CLARITY ANALYZE ----------------
  if (msg.type === "CLARITY_ANALYZE") {
    fetch("http://127.0.0.1:8002/clarity/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: msg.text })
    })
      .then(res => res.json())
      .then(data => {
        sendResponse(data);
      })
      .catch(err => {
        console.error("Clarity analyze error:", err);
        sendResponse({ error: true });
      });

    return true;
  }

  // ---------------- CLARITY IMPROVE ----------------
  if (msg.type === "CLARITY_IMPROVE") {
    fetch("http://127.0.0.1:8002/clarity/improve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: msg.text })
    })
      .then(res => res.json())
      .then(data => {
        sendResponse(data);
      })
      .catch(err => {
        console.error("Clarity improve error:", err);
        sendResponse({ error: true });
      });

    return true;
  }
});

